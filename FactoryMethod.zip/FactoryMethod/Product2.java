public class Product2 extends FatherProd
{
    public void complex1()
    {
        System.out.println("Compleja1");
    }

    public void complex2()
    {
        System.out.println("Compleja2");
    }
}