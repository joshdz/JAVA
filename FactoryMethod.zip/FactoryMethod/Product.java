public class Product extends FatherProd
{
    void construirParte1()
    {
            System.out.println("Construyendo la primera parte");
    }

    void construirParte2()
    {
            System.out.println("Construyendo parte compleja dos");
    }
    
}