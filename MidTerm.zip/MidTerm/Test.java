public class Test{

    public static void main(String[] args) {
        
        Creator c = new ConcreteCreator();
        SuperCracker s = c.factoryMethod("Cracker", new Dictionary(),"localhost", "255.255.255.255");
        System.out.println(s);
    }
}